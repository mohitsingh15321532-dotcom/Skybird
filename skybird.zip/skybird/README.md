# 🐦 SkyBird – Flutter Flame Game

A complete, original Flappy-Bird-inspired mobile game built with Flutter and the Flame engine.

---

## Project Structure

```
skybird/
├── lib/
│   ├── main.dart                       ← App entry point
│   ├── game/
│   │   ├── skybird_game.dart           ← Root FlameGame class
│   │   └── components/
│   │       ├── background_component.dart
│   │       ├── cloud_component.dart
│   │       ├── ground_component.dart
│   │       ├── player_component.dart
│   │       ├── obstacle_component.dart  ← Crystal pillar pair
│   │       ├── obstacle_manager.dart    ← Spawner & recycler
│   │       └── score_component.dart     ← In-game HUD
│   ├── screens/
│   │   ├── home_screen.dart
│   │   ├── character_select_screen.dart
│   │   ├── game_screen.dart
│   │   ├── high_score_screen.dart
│   │   └── settings_screen.dart
│   ├── widgets/
│   │   ├── animated_sky_background.dart
│   │   ├── sky_button.dart
│   │   └── game_overlay.dart           ← Start/Pause/GameOver panels
│   ├── models/
│   │   ├── character_model.dart
│   │   └── game_state.dart
│   ├── services/
│   │   ├── storage_service.dart        ← SharedPreferences wrapper
│   │   └── audio_service.dart          ← flame_audio wrapper
│   └── utils/
│       └── game_constants.dart         ← All tunable numbers
├── assets/
│   ├── images/
│   │   ├── player1.png  …  player5.png  ← Replace with real faces
│   │   ├── background.png
│   │   ├── cloud1.png, cloud2.png
│   │   ├── ground.png
│   │   ├── pillar_top.png, pillar_bottom.png, pillar_cap.png
│   │   ├── logo.png
│   │   └── star.png
│   └── audio/
│       ├── background_music.mp3  ← Replace with real track
│       ├── jump.wav
│       ├── score.wav
│       ├── hit.wav
│       └── gameover.wav
├── android/
│   └── app/
│       ├── build.gradle             ← minSdk 29 (Android 10)
│       └── src/main/
│           └── AndroidManifest.xml  ← Portrait lock
├── pubspec.yaml
└── README.md
```

---

## Prerequisites

| Tool            | Version  |
|-----------------|----------|
| Flutter SDK     | ≥ 3.19   |
| Dart SDK        | ≥ 3.0    |
| Android SDK     | API 29+  |
| Java / JDK      | 17       |

---

## Setup & Run

### 1. Install Flutter
Follow: https://docs.flutter.dev/get-started/install

### 2. Clone / copy the project
```bash
cd skybird
flutter pub get
```

### 3. Connect an Android device or start an emulator
```bash
flutter devices
```

### 4. Run in debug mode
```bash
flutter run
```

### 5. Build a release APK
```bash
flutter build apk --release
# Output: build/app/outputs/flutter-apk/app-release.apk
```

---

## Replacing Placeholder Assets

### Player Portraits (`assets/images/player1-5.png`)
- Replace each file with a **128×128** (or larger) PNG of a circular face photo.
- The game clips them to a circle automatically — no need to pre-crop.

### Background Music (`assets/audio/background_music.mp3`)
- Drop in any royalty-free looping MP3.
- Recommended: 2–3 minute loop at ~128kbps.

### Sound Effects (`assets/audio/*.wav`)
- Replace each WAV with original sound effects.
- Target: 16-bit, 44100 Hz, mono or stereo.

---

## Gameplay

| Action          | Control               |
|-----------------|-----------------------|
| Flap up         | Tap anywhere          |
| Pause           | Tap ⏸ (top-right)     |
| Resume          | Tap ▶ on pause panel  |
| Restart         | Tap ↺ on game-over    |

**Difficulty** scales automatically with your score:
- Pillars move faster every point.
- The gap between pillars narrows.
- Pillar spacing decreases.

---

## Adding New Features (Modular Hooks)

| Feature          | Where to extend                                          |
|------------------|----------------------------------------------------------|
| Coins / pickups  | Add new `PositionComponent` + spawn in `ObstacleManager` |
| Power-ups        | Add state flags to `SkyBirdGame` + apply in `PlayerComponent` |
| Achievements     | Add achievement IDs to `StorageService`                  |
| Skins / outfits  | Extend `CharacterModel` with `skinPath` field            |
| Leaderboard      | Replace `HighScoreScreen` with cloud API call            |
| Multiplayer      | Add a `NetworkService` and sync `PlayerComponent` positions |

---

## Android Compatibility

- **Minimum SDK:** 29 (Android 10)
- **Target SDK:** 34
- **Orientation:** Portrait only (enforced in manifest + system call)
- **Performance:** Flame renders via Flutter's Skia/Impeller; no native plugins required.

---

## License

All code in this project is original and copyright-free.  
Replace placeholder audio/images with your own royalty-free or original assets before publishing.
