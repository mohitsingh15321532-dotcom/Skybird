/// All numeric constants that define game feel and difficulty.
/// Centralised here so future tuning / A-B testing is easy.
class GameConstants {
  GameConstants._();

  // ---------------------------------------------------------------------------
  // World
  // ---------------------------------------------------------------------------
  static const double gravity          = 1400.0;  // pixels / s²
  static const double groundHeight     = 80.0;    // px from bottom

  // ---------------------------------------------------------------------------
  // Player
  // ---------------------------------------------------------------------------
  static const double playerSize       = 60.0;    // diameter in px
  static const double flapImpulse      = -480.0;  // upward velocity on tap (negative = up)
  static const double playerStartX     = 0.25;    // fraction of screen width
  static const double playerStartY     = 0.45;    // fraction of screen height
  static const double maxFallVelocity  = 700.0;   // terminal velocity downward
  static const double rotationMax      =  0.4;    // radians max tilt (nose-down)
  static const double rotationMin      = -0.3;    // radians max tilt (nose-up)

  // ---------------------------------------------------------------------------
  // Obstacles (crystal pillars)
  // ---------------------------------------------------------------------------
  static const double pillarWidth      = 72.0;
  static const double pillarMinHeight  = 80.0;    // shortest visible pillar
  static const double gapSizeBase      = 200.0;   // initial gap between top & bottom pillar
  static const double gapSizeMin       = 120.0;   // narrowest allowed gap
  static const double pillarSpacingBase = 280.0;  // horizontal space between pairs
  static const double pillarSpacingMin  = 200.0;

  // ---------------------------------------------------------------------------
  // Speed & Difficulty
  // ---------------------------------------------------------------------------
  static const double scrollSpeedBase  = 180.0;   // initial px/s
  static const double scrollSpeedMax   = 420.0;   // cap
  static const double speedIncrement   = 8.0;     // px/s added per point scored
  static const double gapDecrement     = 2.5;     // px removed from gap per point
  static const double spacingDecrement = 2.0;     // px removed from spacing per point

  // ---------------------------------------------------------------------------
  // Clouds
  // ---------------------------------------------------------------------------
  static const int    cloudCount       = 5;
  static const double cloudSpeedMin    = 30.0;
  static const double cloudSpeedMax    = 70.0;

  // ---------------------------------------------------------------------------
  // Scoring
  // ---------------------------------------------------------------------------
  static const double scoreZoneX       = 0.0;     // x offset relative to pillar center
}
