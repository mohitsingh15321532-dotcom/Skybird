import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/game_state.dart';
import '../game/skybird_game.dart';

/// Composite overlay that shows different panels based on [gameState].
/// All game state transitions are triggered via callbacks to [SkyBirdGame].
class GameOverlay extends StatelessWidget {
  final SkyBirdGame    game;
  final GameState      gameState;
  final int            score;
  final int            highScore;
  final VoidCallback   onStart;
  final VoidCallback   onPause;
  final VoidCallback   onResume;
  final VoidCallback   onRestart;
  final VoidCallback   onMainMenu;

  const GameOverlay({
    super.key,
    required this.game,
    required this.gameState,
    required this.score,
    required this.highScore,
    required this.onStart,
    required this.onPause,
    required this.onResume,
    required this.onRestart,
    required this.onMainMenu,
  });

  @override
  Widget build(BuildContext context) {
    return switch (gameState) {
      GameState.idle     => _ReadyPanel(onStart: onStart),
      GameState.playing  => _HudPanel(
          score:     score,
          highScore: highScore,
          onPause:   onPause,
        ),
      GameState.paused   => _PausePanel(
          onResume:   onResume,
          onMainMenu: onMainMenu,
        ),
      GameState.gameOver => _GameOverPanel(
          score:      score,
          highScore:  highScore,
          onRestart:  onRestart,
          onMainMenu: onMainMenu,
        ),
    };
  }
}

// ── Panels ──────────────────────────────────────────────────────────────────

/// Initial "tap to start" screen.
class _ReadyPanel extends StatelessWidget {
  final VoidCallback onStart;
  const _ReadyPanel({required this.onStart});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onStart,
      child: Container(
        color: Colors.transparent,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 120),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 28, vertical: 20),
                decoration: BoxDecoration(
                  color:        Colors.black54,
                  borderRadius: BorderRadius.circular(20),
                  border:       Border.all(color: Colors.white24),
                ),
                child: Column(
                  children: [
                    Text(
                      'TAP TO FLY!',
                      style: GoogleFonts.bangers(
                        fontSize: 42,
                        color:   Colors.white,
                        letterSpacing: 5,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Tap anywhere to flap upward.\nDodge the crystal pillars!',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white70, fontSize: 14),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// In-game HUD: score, best score, pause button.
class _HudPanel extends StatelessWidget {
  final int score;
  final int highScore;
  final VoidCallback onPause;

  const _HudPanel({
    required this.score,
    required this.highScore,
    required this.onPause,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Stack(
        children: [
          // Best score top-left
          Positioned(
            top: 12, left: 16,
            child: _ScoreBadge(
              label: 'BEST',
              value: highScore,
              color: const Color(0xFFFFD740),
            ),
          ),

          // Pause button top-right
          Positioned(
            top: 8, right: 12,
            child: IconButton(
              onPressed: onPause,
              icon: const Icon(Icons.pause_circle_filled,
                  color: Colors.white70, size: 36),
            ),
          ),
        ],
      ),
    );
  }
}

/// Pause overlay.
class _PausePanel extends StatelessWidget {
  final VoidCallback onResume;
  final VoidCallback onMainMenu;
  const _PausePanel({required this.onResume, required this.onMainMenu});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black54,
      child: Center(
        child: _Card(
          children: [
            Text('PAUSED',
                style: GoogleFonts.bangers(
                    fontSize: 44, color: Colors.white, letterSpacing: 5)),
            const SizedBox(height: 24),
            _OverlayButton(
              label: '▶  RESUME',
              color: const Color(0xFF00E676),
              onTap: onResume,
            ),
            const SizedBox(height: 12),
            _OverlayButton(
              label: '⌂  MAIN MENU',
              color: const Color(0xFF607D8B),
              onTap: onMainMenu,
            ),
          ],
        ),
      ),
    );
  }
}

/// Game-over overlay.
class _GameOverPanel extends StatelessWidget {
  final int score;
  final int highScore;
  final VoidCallback onRestart;
  final VoidCallback onMainMenu;

  const _GameOverPanel({
    required this.score,
    required this.highScore,
    required this.onRestart,
    required this.onMainMenu,
  });

  @override
  Widget build(BuildContext context) {
    final isNewRecord = score > 0 && score >= highScore;

    return Container(
      color: Colors.black54,
      child: Center(
        child: _Card(
          children: [
            Text('GAME OVER',
                style: GoogleFonts.bangers(
                    fontSize: 46,
                    color: const Color(0xFFFF5252),
                    letterSpacing: 5)),
            if (isNewRecord) ...[
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color:        const Color(0xFFFFD740),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  '✨ NEW RECORD!',
                  style: GoogleFonts.rajdhani(
                    fontSize: 14, fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
              ),
            ],
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _ScoreBadge(
                    label: 'SCORE', value: score, color: Colors.white),
                _ScoreBadge(
                    label: 'BEST',
                    value: highScore,
                    color: const Color(0xFFFFD740)),
              ],
            ),
            const SizedBox(height: 28),
            _OverlayButton(
              label: '↺  PLAY AGAIN',
              color: const Color(0xFF00E676),
              onTap: onRestart,
            ),
            const SizedBox(height: 12),
            _OverlayButton(
              label: '⌂  MAIN MENU',
              color: const Color(0xFF607D8B),
              onTap: onMainMenu,
            ),
          ],
        ),
      ),
    );
  }
}

// ── Shared small widgets ─────────────────────────────────────────────────────

class _Card extends StatelessWidget {
  final List<Widget> children;
  const _Card({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin:  const EdgeInsets.symmetric(horizontal: 32),
      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 28),
      decoration: BoxDecoration(
        color:        const Color(0xDD1A1A2E),
        borderRadius: BorderRadius.circular(24),
        border:       Border.all(color: Colors.white24),
        boxShadow: const [
          BoxShadow(color: Colors.black38, blurRadius: 20),
        ],
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: children),
    );
  }
}

class _OverlayButton extends StatelessWidget {
  final String       label;
  final Color        color;
  final VoidCallback onTap;
  const _OverlayButton({required this.label, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 48,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12)),
        ),
        child: Text(
          label,
          style: GoogleFonts.rajdhani(
              fontSize: 17, fontWeight: FontWeight.bold, letterSpacing: 1.5),
        ),
      ),
    );
  }
}

class _ScoreBadge extends StatelessWidget {
  final String label;
  final int    value;
  final Color  color;
  const _ScoreBadge(
      {required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(label,
            style: TextStyle(
                color: color.withOpacity(0.8),
                fontSize: 12,
                letterSpacing: 2)),
        const SizedBox(height: 2),
        Text('$value',
            style: GoogleFonts.bangers(
                fontSize: 48, color: color, letterSpacing: 2)),
      ],
    );
  }
}
