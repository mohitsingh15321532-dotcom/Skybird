import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// A stylised pill button used throughout the menu system.
class SkyButton extends StatelessWidget {
  final String    label;
  final Color     color;
  final VoidCallback onTap;
  final double    fontSize;

  const SkyButton({
    super.key,
    required this.label,
    required this.color,
    required this.onTap,
    this.fontSize = 18,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Ink(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [color, color.withOpacity(0.75)],
                begin:  Alignment.topLeft,
                end:    Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color:       color.withOpacity(0.45),
                  blurRadius:  12,
                  spreadRadius: 1,
                  offset:      const Offset(0, 4),
                ),
              ],
            ),
            child: Container(
              height: 52,
              alignment: Alignment.center,
              child: Text(
                label,
                style: GoogleFonts.rajdhani(
                  fontSize:   fontSize,
                  fontWeight: FontWeight.bold,
                  color:      Colors.white,
                  letterSpacing: 1.5,
                  shadows: const [
                    Shadow(color: Colors.black26, blurRadius: 3),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
