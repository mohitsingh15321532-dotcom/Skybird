import 'dart:math';
import 'package:flutter/material.dart';

/// A pure-Flutter animated sky gradient used on all non-game screens.
/// Gives consistent branding without any asset dependency.
class AnimatedSkyBackground extends StatefulWidget {
  const AnimatedSkyBackground({super.key});

  @override
  State<AnimatedSkyBackground> createState() => _AnimatedSkyBackgroundState();
}

class _AnimatedSkyBackgroundState extends State<AnimatedSkyBackground>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync:    this,
      duration: const Duration(seconds: 8),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) {
        final t = _ctrl.value;
        return CustomPaint(
          painter: _SkyPainter(t),
          child: const SizedBox.expand(),
        );
      },
    );
  }
}

class _SkyPainter extends CustomPainter {
  final double t;
  _SkyPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();

    // Animated gradient shift
    final topColor = Color.lerp(
      const Color(0xFF1A237E),
      const Color(0xFF311B92),
      t,
    )!;
    final midColor = Color.lerp(
      const Color(0xFF4FC3F7),
      const Color(0xFF0288D1),
      t,
    )!;
    final botColor = Color.lerp(
      const Color(0xFF80DEEA),
      const Color(0xFF4DB6AC),
      t,
    )!;

    paint.shader = LinearGradient(
      begin:  Alignment.topCenter,
      end:    Alignment.bottomCenter,
      colors: [topColor, midColor, botColor],
      stops:  const [0.0, 0.55, 1.0],
    ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    canvas.drawRect(
        Rect.fromLTWH(0, 0, size.width, size.height), paint);

    // Stars (visible at top, fading with t)
    final starPaint = Paint()..color = Colors.white.withOpacity((1 - t) * 0.7);
    final rng       = Random(42); // fixed seed = same stars every frame
    for (int i = 0; i < 50; i++) {
      final x = rng.nextDouble() * size.width;
      final y = rng.nextDouble() * size.height * 0.45;
      final r = rng.nextDouble() * 1.5 + 0.5;
      canvas.drawCircle(Offset(x, y), r, starPaint);
    }
  }

  @override
  bool shouldRepaint(_SkyPainter old) => old.t != t;
}
