import 'dart:math';
import 'package:flame/components.dart';
import 'package:flame/collisions.dart';
import 'package:flutter/material.dart';
import '../../utils/game_constants.dart';
import '../skybird_game.dart';

/// One pair of top + bottom crystal pillars with a gap between them.
/// Notifies [onScore] when the player passes through the scoring zone.
class ObstaclePair extends PositionComponent
    with HasGameReference<SkyBirdGame> {

  final double   gapCenter; // y position of the center of the gap
  final double   gapSize;
  final VoidCallback onScore;

  bool _scored = false;

  // Pillar colours – original crystal aesthetic, not pipe-green
  static const _crystalTop    = Color(0xFF7C4DFF); // deep violet
  static const _crystalMid    = Color(0xFFB39DDB); // lavender
  static const _crystalBottom = Color(0xFF311B92); // darkest at edges
  static const _capColor      = Color(0xFFD1C4E9); // light lilac cap

  final _pillarPaint = Paint();
  final _capPaint    = Paint()..color = _capColor;
  final _glowPaint   = Paint()
    ..color       = const Color(0x33B39DDB)
    ..maskFilter  = const MaskFilter.blur(BlurStyle.normal, 8);

  ObstaclePair({
    required double startX,
    required this.gapCenter,
    required this.gapSize,
    required this.onScore,
  }) {
    position = Vector2(startX, 0);
  }

  @override
  Future<void> onLoad() async {
    final screenH    = game.size.y;
    final w          = GameConstants.pillarWidth;
    final groundTop  = screenH - GameConstants.groundHeight;

    // Top pillar height
    final topH   = gapCenter - gapSize / 2;
    // Bottom pillar starts below the gap and goes to ground
    final botY   = gapCenter + gapSize / 2;
    final botH   = groundTop - botY;

    size = Vector2(w, screenH);

    // ── Hitboxes ────────────────────────────────────────────────────────
    if (topH > 0) {
      add(RectangleHitbox(
        position: Vector2(0, 0),
        size:     Vector2(w, topH),
      ));
    }
    if (botH > 0) {
      add(RectangleHitbox(
        position: Vector2(0, botY),
        size:     Vector2(w, botH),
      ));
    }
  }

  @override
  void update(double dt) {
    position.x -= game.currentScrollSpeed * dt;

    // Score: when leading edge passes the player x position
    final playerX = game.size.x * GameConstants.playerStartX;
    if (!_scored && position.x + GameConstants.pillarWidth < playerX) {
      _scored = true;
      onScore();
    }
  }

  @override
  void render(Canvas canvas) {
    final screenH   = game.size.y;
    final groundTop = screenH - GameConstants.groundHeight;
    final w         = GameConstants.pillarWidth;
    final topH      = gapCenter - gapSize / 2;
    final botY      = gapCenter + gapSize / 2;
    final botH      = groundTop - botY;

    // ── Gradient paint ──────────────────────────────────────────────────
    void drawPillar(double y, double h) {
      if (h <= 0) return;
      final rect = Rect.fromLTWH(0, y, w, h);

      // Glow
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect.inflate(4), const Radius.circular(6)),
        _glowPaint,
      );

      // Main crystal gradient
      _pillarPaint.shader = LinearGradient(
        begin: Alignment.centerLeft,
        end:   Alignment.centerRight,
        colors: [_crystalBottom, _crystalMid, _crystalTop, _crystalMid, _crystalBottom],
        stops: const [0.0, 0.2, 0.5, 0.8, 1.0],
      ).createShader(rect);
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect, const Radius.circular(4)),
        _pillarPaint,
      );

      // Highlight stripe
      final highlightPaint = Paint()
        ..color       = Colors.white.withOpacity(0.25)
        ..strokeWidth = 4;
      canvas.drawLine(
        Offset(w * 0.3, y + 4),
        Offset(w * 0.3, y + h - 4),
        highlightPaint,
      );
    }

    void drawCap(double y, bool isTop) {
      const capH = 18.0;
      final capY = isTop ? y - capH : y;
      final rect = Rect.fromLTWH(-4, capY, w + 8, capH);
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect, const Radius.circular(5)),
        _capPaint,
      );
      // Crystal spike details on cap
      final spikePaint = Paint()..color = const Color(0xFFEDE7F6);
      for (int i = 0; i < 3; i++) {
        final sx = 10.0 + i * 18.0;
        if (isTop) {
          canvas.drawLine(Offset(sx, capY), Offset(sx + 6, capY - 10), spikePaint..strokeWidth = 3);
        } else {
          canvas.drawLine(Offset(sx, capY + capH), Offset(sx + 6, capY + capH + 10), spikePaint..strokeWidth = 3);
        }
      }
    }

    // Draw top pillar
    if (topH > 0) {
      drawPillar(0, topH);
      drawCap(topH, true);
    }

    // Draw bottom pillar
    if (botH > 0) {
      drawPillar(botY, botH);
      drawCap(botY, false);
    }
  }

  bool get isOffScreen => position.x + GameConstants.pillarWidth < 0;
}
