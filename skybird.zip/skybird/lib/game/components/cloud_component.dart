import 'dart:math';
import 'package:flame/components.dart';
import 'package:flutter/material.dart';
import '../../utils/game_constants.dart';
import '../skybird_game.dart';
import '../../models/game_state.dart';

/// A single procedurally drawn cloud that drifts left.
class _Cloud {
  double x, y, speed, scale;
  _Cloud({required this.x, required this.y, required this.speed, required this.scale});
}

/// Manages a pool of scrolling clouds rendered with Canvas – no image asset needed.
class CloudComponent extends Component with HasGameReference<SkyBirdGame> {
  final _clouds = <_Cloud>[];
  final _rng    = Random();
  final _paint  = Paint()..color = Colors.white.withOpacity(0.85);

  @override
  Future<void> onLoad() async {
    final w = game.size.x;
    final h = game.size.y;

    for (int i = 0; i < GameConstants.cloudCount; i++) {
      _clouds.add(_Cloud(
        x:     _rng.nextDouble() * w,
        y:     _rng.nextDouble() * h * 0.55 + 20,
        speed: _rng.nextDouble() *
               (GameConstants.cloudSpeedMax - GameConstants.cloudSpeedMin) +
               GameConstants.cloudSpeedMin,
        scale: _rng.nextDouble() * 0.6 + 0.5,
      ));
    }
  }

  @override
  void update(double dt) {
    if (game.gameState != GameState.playing) return;

    final w = game.size.x;
    for (final cloud in _clouds) {
      cloud.x -= cloud.speed * dt;
      if (cloud.x < -120 * cloud.scale) {
        // Respawn off the right edge
        cloud.x     = w + _rng.nextDouble() * 200;
        cloud.y     = _rng.nextDouble() * game.size.y * 0.5 + 20;
        cloud.scale = _rng.nextDouble() * 0.6 + 0.5;
        cloud.speed = _rng.nextDouble() *
                      (GameConstants.cloudSpeedMax - GameConstants.cloudSpeedMin) +
                      GameConstants.cloudSpeedMin;
      }
    }
  }

  @override
  void render(Canvas canvas) {
    for (final cloud in _clouds) {
      _drawCloud(canvas, cloud);
    }
  }

  void _drawCloud(Canvas canvas, _Cloud c) {
    canvas.save();
    canvas.translate(c.x, c.y);
    canvas.scale(c.scale);

    // Three overlapping circles = a simple fluffy cloud
    canvas.drawCircle(const Offset(0, 0),   28, _paint);
    canvas.drawCircle(const Offset(32, -8), 22, _paint);
    canvas.drawCircle(const Offset(-30, -4),20, _paint);
    canvas.drawRect(
      Rect.fromLTWH(-30, 0, 90, 24),
      _paint,
    );

    canvas.restore();
  }
}
