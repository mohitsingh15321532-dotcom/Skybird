import 'package:flame/components.dart';
import 'package:flutter/material.dart';
import '../skybird_game.dart';
import '../../models/game_state.dart';

/// Lightweight score overlay drawn directly in the Flame canvas.
/// The Flutter overlay (game_overlay.dart) shows the full HUD;
/// this component renders the score text during gameplay for minimum latency.
class ScoreComponent extends TextComponent with HasGameReference<SkyBirdGame> {

  ScoreComponent() : super(
    text: '',
    textRenderer: TextPaint(
      style: const TextStyle(
        color:      Colors.white,
        fontSize:   48,
        fontWeight: FontWeight.bold,
        shadows: [
          Shadow(color: Colors.black54, blurRadius: 4, offset: Offset(2, 2)),
        ],
      ),
    ),
  );

  @override
  Future<void> onLoad() async {
    anchor = Anchor.topCenter;
    position = Vector2(game.size.x / 2, 60);
  }

  @override
  void update(double dt) {
    if (game.gameState == GameState.playing) {
      text = game.score.toString();
    } else {
      text = '';
    }
  }
}
