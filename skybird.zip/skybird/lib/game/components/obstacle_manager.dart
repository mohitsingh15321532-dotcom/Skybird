import 'dart:math';
import 'package:flame/components.dart';
import 'package:flutter/material.dart';
import '../../models/game_state.dart';
import '../../utils/game_constants.dart';
import '../skybird_game.dart';
import 'obstacle_component.dart';

/// Manages the pool of [ObstaclePair] components.
/// Spawns new pairs, removes off-screen ones, and forwards score events.
class ObstacleManager extends Component with HasGameReference<SkyBirdGame> {

  final VoidCallback onScore;
  ObstacleManager({required this.onScore});

  final _rng       = Random();
  final _obstacles = <ObstaclePair>[];
  double _spawnTimer = 0;

  // Derived each frame from current difficulty
  double get _spacing => game.currentPillarSpacing + GameConstants.pillarWidth;

  @override
  void update(double dt) {
    if (game.gameState != GameState.playing) return;

    _spawnTimer += game.currentScrollSpeed * dt;

    if (_spawnTimer >= _spacing) {
      _spawnTimer -= _spacing;
      _spawnPair();
    }

    // Remove off-screen obstacles
    for (final obs in List.of(_obstacles)) {
      if (obs.isOffScreen) {
        _obstacles.remove(obs);
        game.remove(obs);
      }
    }
  }

  void _spawnPair() {
    final screenH    = game.size.y;
    final groundTop  = screenH - GameConstants.groundHeight;
    final gap        = game.currentGapSize;

    // Random gap center within valid vertical range
    final minCenter  = GameConstants.pillarMinHeight + gap / 2;
    final maxCenter  = groundTop - GameConstants.pillarMinHeight - gap / 2;
    final gapCenter  = minCenter + _rng.nextDouble() * (maxCenter - minCenter);

    final pair = ObstaclePair(
      startX:    game.size.x + 10,
      gapCenter: gapCenter,
      gapSize:   gap,
      onScore:   onScore,
    );

    _obstacles.add(pair);
    game.add(pair);
  }

  /// Clear all obstacles and reset spawn timer (called on restart).
  void reset() {
    for (final obs in List.of(_obstacles)) {
      game.remove(obs);
    }
    _obstacles.clear();
    _spawnTimer = 0;
  }

  /// Called when score changes so future spawns use updated difficulty.
  void onScoreChanged(int score) {
    // Currently difficulty is derived from game.score directly via getters.
    // Hook here to add power-ups, special events, etc. in the future.
  }
}
