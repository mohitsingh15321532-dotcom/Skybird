import 'dart:math';
import 'package:flame/components.dart';
import 'package:flame/collisions.dart';
import 'package:flutter/material.dart';
import '../../models/character_model.dart';
import '../../models/game_state.dart';
import '../../utils/game_constants.dart';
import '../skybird_game.dart';

/// The player-controlled flying character.
/// Rendered as a circular clipped portrait image that tilts with velocity.
/// Falls under gravity; tapping the screen calls [flap()].
class PlayerComponent extends PositionComponent
    with HasGameReference<SkyBirdGame>, CollisionCallbacks {

  final CharacterModel character;
  final VoidCallback   onCollision;

  PlayerComponent({
    required this.character,
    required this.onCollision,
  });

  // ── Physics ─────────────────────────────────────────────────────────────
  double _velocityY   = 0;
  bool   _isDead      = false;

  // ── Sprite ──────────────────────────────────────────────────────────────
  Sprite? _sprite;

  // ── Rotation animation ──────────────────────────────────────────────────
  // Slight continuous spin when alive (wobble)
  double _wobbleAngle = 0;

  // ── Collision flag ──────────────────────────────────────────────────────
  bool _collisionReported = false;

  // ── Paints for fallback rendering ────────────────────────────────────────
  final _bgPaint = Paint()
    ..color = const Color(0xFF4FC3F7)
    ..style  = PaintingStyle.fill;

  final _borderPaint = Paint()
    ..color       = Colors.white
    ..style        = PaintingStyle.stroke
    ..strokeWidth  = 3;

  @override
  Future<void> onLoad() async {
    final s = GameConstants.playerSize;
    size     = Vector2(s, s);

    // Position at configured starting fraction of screen
    position = Vector2(
      game.size.x * GameConstants.playerStartX - s / 2,
      game.size.y * GameConstants.playerStartY - s / 2,
    );

    // Load player portrait
    try {
      _sprite = await game.loadSprite(character.assetPath);
    } catch (_) {
      // Fallback if asset missing – will render a colored circle
      _sprite = null;
    }

    // Circular hitbox (slightly smaller than visual for fair collisions)
    add(CircleHitbox(
      radius: s / 2 * 0.80,
      anchor: Anchor.center,
      position: Vector2(s / 2, s / 2),
    ));
  }

  // -----------------------------------------------------------------------
  // Physics update
  // -----------------------------------------------------------------------
  @override
  void update(double dt) {
    if (game.gameState != GameState.playing || _isDead) return;

    // Apply gravity
    _velocityY += GameConstants.gravity * dt;

    // Cap terminal velocity
    if (_velocityY > GameConstants.maxFallVelocity) {
      _velocityY = GameConstants.maxFallVelocity;
    }

    // Move player vertically
    position.y += _velocityY * dt;

    // Wobble rotation based on velocity (tilt nose-up when rising, down when falling)
    final targetAngle = (_velocityY / GameConstants.maxFallVelocity) *
        GameConstants.rotationMax;
    angle = targetAngle.clamp(GameConstants.rotationMin, GameConstants.rotationMax);

    // Subtle additional spin animation for liveliness
    _wobbleAngle += 1.2 * dt;

    // Prevent going above screen
    if (position.y < -size.y) {
      position.y = -size.y;
      _velocityY = 0;
    }
  }

  // -----------------------------------------------------------------------
  // Rendering
  // -----------------------------------------------------------------------
  @override
  void render(Canvas canvas) {
    final center = Offset(size.x / 2, size.y / 2);
    final radius = size.x / 2;

    // Clip to circle
    canvas.save();
    final clipPath = Path()
      ..addOval(Rect.fromCircle(center: center, radius: radius));
    canvas.clipPath(clipPath);

    if (_sprite != null) {
      _sprite!.render(
        canvas,
        position: Vector2.zero(),
        size: size,
      );
    } else {
      // Fallback: coloured circle with initial letter
      canvas.drawCircle(center, radius, _bgPaint);
      final textPainter = TextPainter(
        text: TextSpan(
          text: character.name[0],
          style: const TextStyle(
            color: Colors.white,
            fontSize: 28,
            fontWeight: FontWeight.bold,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      textPainter.paint(
        canvas,
        Offset(center.dx - textPainter.width / 2,
               center.dy - textPainter.height / 2),
      );
    }

    canvas.restore();

    // White border ring
    canvas.drawCircle(center, radius - 1, _borderPaint);
  }

  // -----------------------------------------------------------------------
  // Public API
  // -----------------------------------------------------------------------

  /// Tap/flap upward impulse.
  void flap() {
    if (_isDead) return;
    _velocityY = GameConstants.flapImpulse;
  }

  /// Reset to starting position for a new game.
  void reset() {
    _isDead    = false;
    _velocityY = 0;
    _collisionReported = false;
    angle      = 0;

    position = Vector2(
      game.size.x * GameConstants.playerStartX - size.x / 2,
      game.size.y * GameConstants.playerStartY - size.y / 2,
    );
  }

  // -----------------------------------------------------------------------
  // Collision detection
  // -----------------------------------------------------------------------
  @override
  void onCollisionStart(
    Set<Vector2> intersectionPoints,
    PositionComponent other,
  ) {
    super.onCollisionStart(intersectionPoints, other);
    if (_collisionReported) return;
    _collisionReported = true;
    _isDead            = true;
    _velocityY         = -200; // small bounce on death
    onCollision();
  }
}
