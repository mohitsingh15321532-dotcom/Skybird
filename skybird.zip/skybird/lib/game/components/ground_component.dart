import 'package:flame/components.dart';
import 'package:flame/collisions.dart';
import 'package:flutter/material.dart';
import '../../utils/game_constants.dart';
import '../skybird_game.dart';
import '../../models/game_state.dart';

/// Renders and scrolls the ground strip at the bottom of the screen.
/// Acts as a collision hitbox for death detection.
class GroundComponent extends PositionComponent
    with HasGameReference<SkyBirdGame>, CollisionCallbacks {

  final VoidCallback onGroundHit;

  GroundComponent({required this.onGroundHit});

  static const _grassColor = Color(0xFF66BB6A);
  static const _dirtColor  = Color(0xFF8D6E63);

  final _grassPaint = Paint()..color = _grassColor;
  final _dirtPaint  = Paint()..color = _dirtColor;

  // Two ground tiles for seamless looping scroll
  double _scrollOffset = 0;

  @override
  Future<void> onLoad() async {
    final s = game.size;
    size     = Vector2(s.x, GameConstants.groundHeight);
    position = Vector2(0, s.y - GameConstants.groundHeight);

    add(RectangleHitbox(
      size: Vector2(s.x, GameConstants.groundHeight),
    ));
  }

  @override
  void update(double dt) {
    if (game.gameState != GameState.playing) return;

    _scrollOffset += game.currentScrollSpeed * dt;
    if (_scrollOffset >= size.x) {
      _scrollOffset -= size.x;
    }
  }

  @override
  void render(Canvas canvas) {
    // Dirt base
    canvas.drawRect(
      Rect.fromLTWH(0, 12, size.x, size.y - 12),
      _dirtPaint,
    );

    // Grass top strip
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.x, 14),
      _grassPaint,
    );

    // Simple stripe detail to show movement
    final stripePaint = Paint()
      ..color = const Color(0xFF4CAF50)
      ..strokeWidth = 2;

    for (double x = -_scrollOffset; x < size.x; x += 30) {
      canvas.drawLine(
        Offset(x, 2),
        Offset(x + 15, 2),
        stripePaint,
      );
    }
  }
}
