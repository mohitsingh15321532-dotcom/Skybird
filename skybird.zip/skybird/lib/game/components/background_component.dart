import 'dart:ui' as ui;
import 'package:flame/components.dart';
import 'package:flutter/material.dart';

/// Draws a vertical gradient sky that gives an original look.
/// No external image asset required for the base sky.
/// Optionally loads background.png if it exists as an overlay.
class BackgroundComponent extends Component with HasGameReference {
  static const _topColor    = Color(0xFF1A237E); // deep indigo at top
  static const _midColor    = Color(0xFF4FC3F7); // sky blue middle
  static const _bottomColor = Color(0xFF80DEEA); // light cyan near ground

  final _paint = Paint();

  @override
  void render(Canvas canvas) {
    final size = game.size;

    // Draw gradient sky
    final rect = Rect.fromLTWH(0, 0, size.x, size.y);
    final gradient = ui.Gradient.linear(
      Offset(0, 0),
      Offset(0, size.y),
      [_topColor, _midColor, _bottomColor],
      [0.0, 0.5, 1.0],
    );

    _paint.shader = gradient;
    canvas.drawRect(rect, _paint);
  }
}
