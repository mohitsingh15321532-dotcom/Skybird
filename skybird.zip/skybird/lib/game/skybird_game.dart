import 'dart:ui';
import 'package:flame/game.dart';
import 'package:flame/events.dart';
import 'package:flutter/material.dart' show Colors, ChangeNotifier;

import '../models/game_state.dart';
import '../models/character_model.dart';
import '../services/audio_service.dart';
import '../services/storage_service.dart';
import '../utils/game_constants.dart';

import 'components/background_component.dart';
import 'components/ground_component.dart';
import 'components/cloud_component.dart';
import 'components/player_component.dart';
import 'components/obstacle_manager.dart';
import 'components/score_component.dart';

/// Root Flame game class.
/// Uses [ChangeNotifier] so Flutter overlays can rebuild when state changes.
class SkyBirdGame extends FlameGame
    with TapDetector, HasCollisionDetection, ChangeNotifier {

  // -----------------------------------------------------------------------
  // Public observable state (Flutter overlays listen to these)
  // -----------------------------------------------------------------------
  GameState gameState = GameState.idle;
  int       score     = 0;
  int       highScore = 0;

  // -----------------------------------------------------------------------
  // Configuration
  // -----------------------------------------------------------------------
  CharacterModel selectedCharacter;

  SkyBirdGame({required this.selectedCharacter});

  // -----------------------------------------------------------------------
  // Component references (needed for restart / pause logic)
  // -----------------------------------------------------------------------
  late PlayerComponent    _player;
  late ObstacleManager    _obstacleManager;
  late ScoreComponent     _scoreDisplay;

  // -----------------------------------------------------------------------
  // Flame lifecycle
  // -----------------------------------------------------------------------
  @override
  Color backgroundColor() => const Color(0xFF87CEEB); // sky blue fallback

  @override
  Future<void> onLoad() async {
    highScore = StorageService.instance.highScore;

    await AudioService.instance.init();

    // ── Background layers (drawn first / lowest z-order) ──────────────────
    await add(BackgroundComponent());
    await add(CloudComponent());

    // ── Obstacles ─────────────────────────────────────────────────────────
    _obstacleManager = ObstacleManager(onScore: _onScore);
    await add(_obstacleManager);

    // ── Ground ────────────────────────────────────────────────────────────
    await add(GroundComponent(onGroundHit: _onCollision));

    // ── Player ────────────────────────────────────────────────────────────
    _player = PlayerComponent(
      character: selectedCharacter,
      onCollision: _onCollision,
    );
    await add(_player);

    // ── HUD score display ─────────────────────────────────────────────────
    _scoreDisplay = ScoreComponent();
    await add(_scoreDisplay);

    // Start idle (waiting for first tap / overlay to start)
    _setGameState(GameState.idle);
  }

  // -----------------------------------------------------------------------
  // Tap / input
  // -----------------------------------------------------------------------
  @override
  void onTap() {
    if (gameState == GameState.idle || gameState == GameState.gameOver) return;
    if (gameState == GameState.paused) return;

    _player.flap();
    AudioService.instance.playJump();
  }

  // -----------------------------------------------------------------------
  // Game flow helpers
  // -----------------------------------------------------------------------

  /// Called by Flutter overlay start button.
  void startGame() {
    score = 0;
    _player.reset();
    _obstacleManager.reset();
    _setGameState(GameState.playing);
    AudioService.instance.playMusic();
  }

  void pauseGame() {
    if (gameState != GameState.playing) return;
    pauseEngine();
    AudioService.instance.pauseMusic();
    _setGameState(GameState.paused);
  }

  void resumeGame() {
    if (gameState != GameState.paused) return;
    resumeEngine();
    AudioService.instance.resumeMusic();
    _setGameState(GameState.playing);
  }

  void restartGame() {
    score = 0;
    _player.reset();
    _obstacleManager.reset();
    resumeEngine();
    _setGameState(GameState.playing);
    AudioService.instance.playMusic();
  }

  // -----------------------------------------------------------------------
  // Internal callbacks
  // -----------------------------------------------------------------------

  void _onScore() {
    if (gameState != GameState.playing) return;
    score++;
    AudioService.instance.playScore();

    if (score > highScore) {
      highScore = score;
      StorageService.instance.saveHighScore(highScore);
    }

    // Propagate score to obstacle manager for difficulty scaling
    _obstacleManager.onScoreChanged(score);
    notifyListeners();
  }

  void _onCollision() {
    if (gameState != GameState.playing) return;
    AudioService.instance.playHit();
    Future.delayed(const Duration(milliseconds: 400), () {
      AudioService.instance.stopMusic();
      AudioService.instance.playGameOver();
      pauseEngine();
      _setGameState(GameState.gameOver);
    });
  }

  void _setGameState(GameState state) {
    gameState = state;
    notifyListeners();
  }

  // -----------------------------------------------------------------------
  // Difficulty helpers (queried by components)
  // -----------------------------------------------------------------------

  double get currentScrollSpeed {
    final speed = GameConstants.scrollSpeedBase +
        (score * GameConstants.speedIncrement);
    return speed.clamp(
        GameConstants.scrollSpeedBase, GameConstants.scrollSpeedMax);
  }

  double get currentGapSize {
    final gap = GameConstants.gapSizeBase -
        (score * GameConstants.gapDecrement);
    return gap.clamp(GameConstants.gapSizeMin, GameConstants.gapSizeBase);
  }

  double get currentPillarSpacing {
    final spacing = GameConstants.pillarSpacingBase -
        (score * GameConstants.spacingDecrement);
    return spacing.clamp(
        GameConstants.pillarSpacingMin, GameConstants.pillarSpacingBase);
  }
}
