import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/storage_service.dart';
import '../models/character_model.dart';
import 'character_select_screen.dart';
import 'game_screen.dart';
import 'high_score_screen.dart';
import 'settings_screen.dart';
import '../widgets/animated_sky_background.dart';
import '../widgets/sky_button.dart';

/// Main menu / home screen.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _logoController;
  late Animation<double>   _logoFloat;

  CharacterModel get _character =>
      CharacterModel.all[StorageService.instance.selectedCharacter];

  @override
  void initState() {
    super.initState();
    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _logoFloat = Tween<double>(begin: -6, end: 6).animate(
      CurvedAnimation(parent: _logoController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _logoController.dispose();
    super.dispose();
  }

  void _startGame() {
    Navigator.push(context,
      MaterialPageRoute(
        builder: (_) => GameScreen(character: _character),
      ),
    );
  }

  void _openCharSelect() async {
    await Navigator.push(context,
      MaterialPageRoute(builder: (_) => const CharacterSelectScreen()),
    );
    setState(() {}); // refresh selected character badge
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ── Animated sky ──────────────────────────────────────────────
          const AnimatedSkyBackground(),

          // ── Content ───────────────────────────────────────────────────
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 40),

                // Logo / title
                AnimatedBuilder(
                  animation: _logoFloat,
                  builder: (_, __) => Transform.translate(
                    offset: Offset(0, _logoFloat.value),
                    child: Column(
                      children: [
                        Text(
                          '🐦',
                          style: TextStyle(fontSize: 72),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'SKY BIRD',
                          style: GoogleFonts.bangers(
                            fontSize: 64,
                            color: Colors.white,
                            letterSpacing: 6,
                            shadows: const [
                              Shadow(
                                color:  Color(0xFF1A237E),
                                offset: Offset(3, 3),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                        ),
                        Text(
                          'FLY THROUGH THE CRYSTALS',
                          style: GoogleFonts.rajdhani(
                            fontSize: 14,
                            color: Colors.white70,
                            letterSpacing: 3,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 48),

                // Current character preview
                GestureDetector(
                  onTap: _openCharSelect,
                  child: Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.white.withOpacity(0.3),
                          blurRadius: 12,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: CircleAvatar(
                      radius: 38,
                      backgroundColor: const Color(0x554FC3F7),
                      child: Text(
                        _character.name[0],
                        style: const TextStyle(
                          fontSize: 30,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  _character.name,
                  style: const TextStyle(color: Colors.white70, fontSize: 13),
                ),

                const SizedBox(height: 40),

                // Buttons
                SkyButton(
                  label: '▶  START GAME',
                  color: const Color(0xFF00E676),
                  onTap: _startGame,
                ),
                const SizedBox(height: 14),
                SkyButton(
                  label: '👤  SELECT CHARACTER',
                  color: const Color(0xFF7C4DFF),
                  onTap: _openCharSelect,
                ),
                const SizedBox(height: 14),
                SkyButton(
                  label: '🏆  HIGH SCORES',
                  color: const Color(0xFFFFC400),
                  onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const HighScoreScreen()),
                  ),
                ),
                const SizedBox(height: 14),
                SkyButton(
                  label: '⚙  SETTINGS',
                  color: const Color(0xFF26C6DA),
                  onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const SettingsScreen()),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
