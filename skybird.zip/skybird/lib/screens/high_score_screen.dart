import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/storage_service.dart';
import '../widgets/animated_sky_background.dart';

/// Shows the locally saved high score.
/// Future: replace with a cloud leaderboard.
class HighScoreScreen extends StatelessWidget {
  const HighScoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final high = StorageService.instance.highScore;

    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          const AnimatedSkyBackground(),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  // Back button
                  Align(
                    alignment: Alignment.centerLeft,
                    child: IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.arrow_back_ios,
                          color: Colors.white),
                    ),
                  ),

                  const SizedBox(height: 20),

                  Text(
                    '🏆',
                    style: const TextStyle(fontSize: 72),
                  ),

                  const SizedBox(height: 12),

                  Text(
                    'HIGH SCORE',
                    style: GoogleFonts.bangers(
                      fontSize: 42,
                      color: const Color(0xFFFFD740),
                      letterSpacing: 5,
                      shadows: const [
                        Shadow(
                          color:  Color(0xFF7C4DFF),
                          offset: Offset(3, 3),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 40),

                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 48, vertical: 32),
                    decoration: BoxDecoration(
                      color:        Colors.white.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(24),
                      border:       Border.all(color: Colors.white30),
                    ),
                    child: Column(
                      children: [
                        Text(
                          'YOUR BEST',
                          style: GoogleFonts.rajdhani(
                            fontSize: 16,
                            color:   Colors.white70,
                            letterSpacing: 3,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '$high',
                          style: GoogleFonts.bangers(
                            fontSize: 96,
                            color:   Colors.white,
                            shadows: const [
                              Shadow(
                                color:  Color(0xFFFFD740),
                                offset: Offset(4, 4),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          high == 0
                              ? 'No score yet – play your first game!'
                              : high < 10
                                  ? 'Great start! Keep flying!'
                                  : high < 30
                                      ? 'Impressive! You\'re getting good!'
                                      : 'Crystal Master!',
                          style: const TextStyle(
                            color:    Colors.white70,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const Spacer(),

                  // Future: leaderboard teaser
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color:        Colors.white.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(14),
                      border:       Border.all(color: Colors.white12),
                    ),
                    child: Row(
                      children: const [
                        Icon(Icons.lock, color: Colors.white38, size: 18),
                        SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Global Leaderboard coming soon!',
                            style: TextStyle(color: Colors.white38, fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
