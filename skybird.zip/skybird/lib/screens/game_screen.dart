import 'package:flutter/material.dart';
import 'package:flame/game.dart';
import '../game/skybird_game.dart';
import '../models/character_model.dart';
import '../models/game_state.dart';
import '../widgets/game_overlay.dart';

/// Flutter screen that embeds the Flame game and mounts all overlays.
class GameScreen extends StatefulWidget {
  final CharacterModel character;
  const GameScreen({super.key, required this.character});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  late SkyBirdGame _game;

  @override
  void initState() {
    super.initState();
    _game = SkyBirdGame(selectedCharacter: widget.character);
    // Listen so we can rebuild overlays when game state changes
    _game.addListener(_onGameStateChanged);
  }

  @override
  void dispose() {
    _game.removeListener(_onGameStateChanged);
    _game.dispose();
    super.dispose();
  }

  void _onGameStateChanged() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ── Flame game canvas ──────────────────────────────────────────
          GameWidget(game: _game),

          // ── Overlay layer ─────────────────────────────────────────────
          GameOverlay(
            game:       _game,
            gameState:  _game.gameState,
            score:      _game.score,
            highScore:  _game.highScore,
            onStart:    _game.startGame,
            onPause:    _game.pauseGame,
            onResume:   _game.resumeGame,
            onRestart:  _game.restartGame,
            onMainMenu: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }
}
