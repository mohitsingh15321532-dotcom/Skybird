import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/storage_service.dart';
import '../services/audio_service.dart';
import '../widgets/animated_sky_background.dart';

/// Audio settings screen with music/SFX toggles and volume sliders.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late double _musicVolume;
  late double _sfxVolume;
  late bool   _musicEnabled;
  late bool   _sfxEnabled;

  @override
  void initState() {
    super.initState();
    final s     = StorageService.instance;
    _musicVolume  = s.musicVolume;
    _sfxVolume    = s.sfxVolume;
    _musicEnabled = s.musicEnabled;
    _sfxEnabled   = s.sfxEnabled;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          const AnimatedSkyBackground(),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Back
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
                  ),

                  const SizedBox(height: 12),

                  Text(
                    '⚙  SETTINGS',
                    style: GoogleFonts.bangers(
                      fontSize: 38,
                      color:    Colors.white,
                      letterSpacing: 4,
                      shadows: const [
                        Shadow(color: Color(0xFF1A237E), offset: Offset(2, 2)),
                      ],
                    ),
                  ),

                  const SizedBox(height: 32),

                  // ── Music section ──────────────────────────────────────
                  _SectionHeader(title: '🎵  MUSIC'),
                  const SizedBox(height: 12),
                  _SettingCard(
                    child: Column(
                      children: [
                        _ToggleRow(
                          label: 'Background Music',
                          value: _musicEnabled,
                          onChanged: (v) async {
                            setState(() => _musicEnabled = v);
                            await AudioService.instance.setMusicEnabled(v);
                          },
                        ),
                        const Divider(color: Colors.white12),
                        _VolumeRow(
                          label: 'Volume',
                          value: _musicVolume,
                          enabled: _musicEnabled,
                          onChanged: (v) async {
                            setState(() => _musicVolume = v);
                            await AudioService.instance.setMusicVolume(v);
                          },
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  // ── SFX section ────────────────────────────────────────
                  _SectionHeader(title: '🔊  SOUND EFFECTS'),
                  const SizedBox(height: 12),
                  _SettingCard(
                    child: Column(
                      children: [
                        _ToggleRow(
                          label: 'Sound Effects',
                          value: _sfxEnabled,
                          onChanged: (v) async {
                            setState(() => _sfxEnabled = v);
                            await AudioService.instance.setSfxEnabled(v);
                          },
                        ),
                        const Divider(color: Colors.white12),
                        _VolumeRow(
                          label: 'Volume',
                          value: _sfxVolume,
                          enabled: _sfxEnabled,
                          onChanged: (v) async {
                            setState(() => _sfxVolume = v);
                            await AudioService.instance.setSfxVolume(v);
                          },
                        ),
                      ],
                    ),
                  ),

                  const Spacer(),

                  // Version
                  Center(
                    child: Text(
                      'SkyBird v1.0.0',
                      style: const TextStyle(color: Colors.white24, fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Helper widgets ──────────────────────────────────────────────────────────

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: GoogleFonts.rajdhani(
        fontSize: 16,
        fontWeight: FontWeight.bold,
        color:   Colors.white70,
        letterSpacing: 2,
      ),
    );
  }
}

class _SettingCard extends StatelessWidget {
  final Widget child;
  const _SettingCard({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
      decoration: BoxDecoration(
        color:        Colors.white.withOpacity(0.12),
        borderRadius: BorderRadius.circular(18),
        border:       Border.all(color: Colors.white24),
      ),
      child: child,
    );
  }
}

class _ToggleRow extends StatelessWidget {
  final String label;
  final bool   value;
  final ValueChanged<bool> onChanged;
  const _ToggleRow({required this.label, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(
            child: Text(label,
                style: const TextStyle(color: Colors.white, fontSize: 15)),
          ),
          Switch(
            value:         value,
            onChanged:     onChanged,
            activeColor:   const Color(0xFF00E676),
            inactiveThumbColor: Colors.white38,
          ),
        ],
      ),
    );
  }
}

class _VolumeRow extends StatelessWidget {
  final String label;
  final double value;
  final bool   enabled;
  final ValueChanged<double> onChanged;
  const _VolumeRow({
    required this.label, required this.value,
    required this.enabled, required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(label,
              style: TextStyle(
                  color: enabled ? Colors.white : Colors.white30,
                  fontSize: 15)),
          const SizedBox(width: 12),
          Expanded(
            child: SliderTheme(
              data: SliderTheme.of(context).copyWith(
                activeTrackColor: const Color(0xFF7C4DFF),
                thumbColor:       const Color(0xFFD1C4E9),
                overlayColor:     const Color(0x337C4DFF),
                inactiveTrackColor: Colors.white24,
              ),
              child: Slider(
                value:    value,
                min:      0.0,
                max:      1.0,
                onChanged: enabled ? onChanged : null,
              ),
            ),
          ),
          Text(
            '${(value * 100).round()}%',
            style: TextStyle(
                color: enabled ? Colors.white70 : Colors.white30,
                fontSize: 12),
          ),
        ],
      ),
    );
  }
}
