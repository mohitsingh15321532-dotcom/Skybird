import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/character_model.dart';
import '../services/storage_service.dart';
import '../widgets/animated_sky_background.dart';

/// Grid-based character selection screen.
/// Persists choice via [StorageService].
class CharacterSelectScreen extends StatefulWidget {
  const CharacterSelectScreen({super.key});

  @override
  State<CharacterSelectScreen> createState() => _CharacterSelectScreenState();
}

class _CharacterSelectScreenState extends State<CharacterSelectScreen> {
  int _selected = StorageService.instance.selectedCharacter;

  Future<void> _confirm() async {
    await StorageService.instance.saveSelectedCharacter(_selected);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          const AnimatedSkyBackground(),
          SafeArea(
            child: Column(
              children: [
                // ── Header ──────────────────────────────────────────────
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: Text(
                    'CHOOSE YOUR PILOT',
                    style: GoogleFonts.bangers(
                      fontSize: 36,
                      color: Colors.white,
                      letterSpacing: 4,
                      shadows: const [
                        Shadow(color: Color(0xFF1A237E), offset: Offset(2, 2)),
                      ],
                    ),
                  ),
                ),

                // ── Character grid ────────────────────────────────────
                Expanded(
                  child: GridView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.78,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                    ),
                    itemCount: CharacterModel.all.length,
                    itemBuilder: (_, i) {
                      final c       = CharacterModel.all[i];
                      final isSelected = i == _selected;
                      return GestureDetector(
                        onTap: () => setState(() => _selected = i),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: isSelected
                                ? Colors.white.withOpacity(0.25)
                                : Colors.white.withOpacity(0.10),
                            border: Border.all(
                              color: isSelected
                                  ? const Color(0xFFFFD740)
                                  : Colors.white30,
                              width: isSelected ? 3 : 1,
                            ),
                            boxShadow: isSelected
                                ? [
                                    BoxShadow(
                                      color: const Color(0xFFFFD740).withOpacity(0.4),
                                      blurRadius: 16,
                                      spreadRadius: 2,
                                    )
                                  ]
                                : [],
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              // Portrait circle
                              Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: isSelected
                                        ? const Color(0xFFFFD740)
                                        : Colors.white54,
                                    width: 3,
                                  ),
                                ),
                                child: CircleAvatar(
                                  radius: 44,
                                  backgroundColor: const Color(0x884FC3F7),
                                  // Uses asset image; falls back to initial letter
                                  backgroundImage: AssetImage(
                                    'assets/images/${c.assetPath}',
                                  ),
                                  onBackgroundImageError: (_, __) {},
                                  child: Text(
                                    c.name[0],
                                    style: const TextStyle(
                                      fontSize: 32,
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                c.name,
                                style: GoogleFonts.rajdhani(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: isSelected
                                      ? const Color(0xFFFFD740)
                                      : Colors.white,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 8),
                                child: Text(
                                  c.description,
                                  style: const TextStyle(
                                    fontSize: 11,
                                    color: Colors.white70,
                                  ),
                                  textAlign: TextAlign.center,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              if (isSelected) ...[
                                const SizedBox(height: 6),
                                const Icon(Icons.check_circle,
                                    color: Color(0xFFFFD740), size: 20),
                              ],
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),

                // ── Confirm button ────────────────────────────────────
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: ElevatedButton(
                    onPressed: _confirm,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF00E676),
                      foregroundColor: Colors.black,
                      minimumSize: const Size(double.infinity, 52),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    child: Text(
                      'CONFIRM SELECTION',
                      style: GoogleFonts.rajdhani(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
