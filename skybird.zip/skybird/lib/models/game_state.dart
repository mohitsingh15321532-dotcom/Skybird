/// All possible states the game can be in.
enum GameState {
  idle,      // waiting on home screen (game not started yet)
  playing,   // actively playing
  paused,    // paused mid-game
  gameOver,  // collision detected – showing game-over overlay
}
