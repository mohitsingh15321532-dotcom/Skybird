/// Data model representing one selectable player character.
/// Add more fields here for future "skins" or "power-up" abilities.
class CharacterModel {
  final int    index;
  final String name;
  final String assetPath;   // path inside assets/images/
  final String description; // shown on character-select screen

  const CharacterModel({
    required this.index,
    required this.name,
    required this.assetPath,
    required this.description,
  });

  /// The five built-in characters.
  static const List<CharacterModel> all = [
    CharacterModel(
      index: 0,
      name: 'Mohit',
      assetPath: 'player1.png',
      description: 'The fearless leader. Lightning reflexes.',
    ),
    CharacterModel(
      index: 1,
      name: 'Brijesh',
      assetPath: 'player2.png',
      description: 'Cool under pressure. Born for the sky.',
    ),
    CharacterModel(
      index: 2,
      name: 'Punit',
      assetPath: 'player3.png',
      description: 'Fast and fierce. Never gives up.',
    ),
    CharacterModel(
      index: 3,
      name: 'Shubham',
      assetPath: 'player4.png',
      description: 'Strategic genius. Masters every gap.',
    ),
    CharacterModel(
      index: 4,
      name: 'Krish',
      assetPath: 'player5.png',
      description: 'Unpredictable. Breaks all records.',
    ),
  ];
}
