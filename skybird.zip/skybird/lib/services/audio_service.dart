import 'package:flame_audio/flame_audio.dart';
import 'storage_service.dart';

/// Centralised audio service.
/// All game components call this service instead of FlameAudio directly
/// so that volume/mute changes apply instantly everywhere.
class AudioService {
  AudioService._();
  static final AudioService instance = AudioService._();

  bool _initialised = false;

  // ---------------------------------------------------------------------------
  // Initialisation – call once before the game starts
  // ---------------------------------------------------------------------------
  Future<void> init() async {
    if (_initialised) return;
    _initialised = true;

    // Pre-cache all audio assets
    await FlameAudio.audioCache.loadAll([
      'background_music.mp3',
      'jump.wav',
      'score.wav',
      'hit.wav',
      'gameover.wav',
    ]);
  }

  // ---------------------------------------------------------------------------
  // Background Music
  // ---------------------------------------------------------------------------
  Future<void> playMusic() async {
    final storage = StorageService.instance;
    if (!storage.musicEnabled) return;
    await FlameAudio.bgm.play(
      'background_music.mp3',
      volume: storage.musicVolume,
    );
  }

  void stopMusic() => FlameAudio.bgm.stop();

  void pauseMusic() => FlameAudio.bgm.pause();

  void resumeMusic() => FlameAudio.bgm.resume();

  Future<void> setMusicVolume(double volume) async {
    await StorageService.instance.saveMusicVolume(volume);
    FlameAudio.bgm.audioPlayer.setVolume(volume);
  }

  Future<void> setMusicEnabled(bool enabled) async {
    await StorageService.instance.saveMusicEnabled(enabled);
    if (enabled) {
      await playMusic();
    } else {
      stopMusic();
    }
  }

  // ---------------------------------------------------------------------------
  // Sound Effects
  // ---------------------------------------------------------------------------
  void playJump() => _playSfx('jump.wav');
  void playScore() => _playSfx('score.wav');
  void playHit()   => _playSfx('hit.wav');
  void playGameOver() => _playSfx('gameover.wav');

  void _playSfx(String file) {
    final storage = StorageService.instance;
    if (!storage.sfxEnabled) return;
    FlameAudio.play(file, volume: storage.sfxVolume);
  }

  Future<void> setSfxVolume(double volume) async {
    await StorageService.instance.saveSfxVolume(volume);
  }

  Future<void> setSfxEnabled(bool enabled) async {
    await StorageService.instance.saveSfxEnabled(enabled);
  }
}
