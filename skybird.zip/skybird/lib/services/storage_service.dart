import 'package:shared_preferences/shared_preferences.dart';

/// Singleton service for all persistent data (high score, settings, selected character).
/// Extend this class to add coins, achievements, leaderboard data, etc.
class StorageService {
  StorageService._();
  static final StorageService instance = StorageService._();

  late SharedPreferences _prefs;

  // ---------------------------------------------------------------------------
  // Keys
  // ---------------------------------------------------------------------------
  static const _keyHighScore     = 'high_score';
  static const _keySelectedChar  = 'selected_character';
  static const _keyMusicVolume   = 'music_volume';
  static const _keySfxVolume     = 'sfx_volume';
  static const _keyMusicEnabled  = 'music_enabled';
  static const _keySfxEnabled    = 'sfx_enabled';

  // ---------------------------------------------------------------------------
  // Initialisation
  // ---------------------------------------------------------------------------
  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // ---------------------------------------------------------------------------
  // High Score
  // ---------------------------------------------------------------------------
  int get highScore => _prefs.getInt(_keyHighScore) ?? 0;

  Future<void> saveHighScore(int score) async {
    if (score > highScore) {
      await _prefs.setInt(_keyHighScore, score);
    }
  }

  // ---------------------------------------------------------------------------
  // Character Selection (0-based index)
  // ---------------------------------------------------------------------------
  int get selectedCharacter => _prefs.getInt(_keySelectedChar) ?? 0;

  Future<void> saveSelectedCharacter(int index) async {
    await _prefs.setInt(_keySelectedChar, index);
  }

  // ---------------------------------------------------------------------------
  // Audio Settings
  // ---------------------------------------------------------------------------
  double get musicVolume => _prefs.getDouble(_keyMusicVolume) ?? 0.6;
  double get sfxVolume   => _prefs.getDouble(_keySfxVolume)   ?? 0.8;
  bool   get musicEnabled => _prefs.getBool(_keyMusicEnabled) ?? true;
  bool   get sfxEnabled   => _prefs.getBool(_keySfxEnabled)   ?? true;

  Future<void> saveMusicVolume(double v)  async => _prefs.setDouble(_keyMusicVolume, v);
  Future<void> saveSfxVolume(double v)    async => _prefs.setDouble(_keySfxVolume, v);
  Future<void> saveMusicEnabled(bool e)   async => _prefs.setBool(_keyMusicEnabled, e);
  Future<void> saveSfxEnabled(bool e)     async => _prefs.setBool(_keySfxEnabled, e);
}
